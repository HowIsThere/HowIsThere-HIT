insert into tipo_imagem values(1, 'Categoria');
insert into tipo_imagem values(2, 'Lugar');
insert into tipo_imagem values(3, 'Pessoa');
insert into tipo_imagem values(4, 'Postagem');
insert into tipo_imagem values(5, 'Comentario');
